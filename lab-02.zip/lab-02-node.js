/*
 CIT 281 Lab 1
 Name: Cameron Coleman
 */
function square(num) {
    return num*num;
}
console.log('Square operations:')
for (let i = 2; i <= 10; i+=2){
    console.log(`Square of ${1} is ${square(i)}`);
}
console.log(`Square of 20 is ${square(20)}`);

